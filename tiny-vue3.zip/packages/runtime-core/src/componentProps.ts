

export function initProps(instance, rawProps) {
  instance.props = rawProps || {}
  // attrs
}